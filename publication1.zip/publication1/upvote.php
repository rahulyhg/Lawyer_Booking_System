<?php
require "connect.inc.php";
session_start();
//$user_check=$_SESSION['login_user'];
//$login=$_SESSION["login"];

if(isset($_POST["title"])&&isset($_POST["author"])&&isset($_POST["type"]))
{
	$title=$_POST["title"];
	$author=$_POST["author"];
	$type=$_POST["type"];	
	$query="select upvote from publication where title='$title' and author='$author' and type='$type'";
	$result=mysql_query($query);
	$upvote=mysql_result($result,'0');
	$upvote++;
	$query="Update publication set upvote='$upvote'  where title='$title' and author='$author' and type='$type'";
	$result=mysql_query($query);
	echo "<script>alert('Succesfully upvoted!!');</script>";
	header("refresh:0;url=index.php");
}

?>
