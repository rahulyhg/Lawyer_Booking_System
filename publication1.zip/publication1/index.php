<?php
// Connect to the database
require "connect.inc.php";
session_start();
@$login=$_SESSION['login'];


?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>homepage</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<style>
      body {
        padding: 10px;
      }

      h1 {
          margin: 0 0 0.5em 0;
          color: #343434;
          font-weight: normal;
          font-family: 'Ultra', sans-serif;
          font-size: 36px;
          line-height: 42px;
          text-transform: uppercase;
          text-shadow: 0 2px white, 0 3px #777;
      }

      h2 {
          margin: 1em 0 0.3em 0;
          color: #343434;
          font-weight: normal;
          font-size: 30px;
          line-height: 40px;
          font-family: 'Orienta', sans-serif;
      }

      #employees {
        font-family: "Lucida Sans Unicode", "Lucida Grande", Sans-Serif;
        font-size: 12px;
        background: #fff;
        margin: 15px 25px 0 0;
        border-collapse: collapse;
        text-align: center;
        float: left;
        width: 1000px;
      }

      #employees th {
        font-size: 14px;
        font-weight: normal;
        color: #039;
        padding: 10px 8px;
        border-bottom: 2px solid #6678b1;
      }

      #employees td {
        border-bottom: 1px solid #ccc;
        color: #669;
        padding: 8px 10px;
      }

      #employees tbody tr:hover td {
        color: #009;
      }

      #filter {
        float:left;
      }
    </style>
  
  </head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Publication Management System</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="#">Home</a></li>
    </ul>
    <?php
	if($login==0){
	
	?>
	<ul class="nav navbar-nav navbar-right">
      
      <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
      <li><a href="signup.php"> Sign Up</a></li>
    </ul>
	<?php
	}
	else{
	?>
	<ul class="nav navbar-nav navbar-right">
      
      <li><a href="admin.php"> View Profile </a></li>
      <li><a href="logout.php"> Log Out </a></li>
    </ul>
	
	<?php
	}
	?>
  </div>
</nav>

    <h1>Online Publications</h1>
	

<div class="row">
	<div style="margin:20px;"class="panel panel-default col-md-2"><div class="panel-body">
	<center><span style="font-size:15px;">Search By Department </span></center><br>
	<form role="form" method="POST" action="index.php">
                            <select class="form-control" name="department">
                                <option selected>CSE</option>
                                <option >Electrical</option>
                                <option>Mechanical</option>
                                <option >System Science</option>
                                <option >BISS</option>
                              </select>
				<br>
				<input type="submit"  value="Search" class="btn btn-primary btn-block"/>
    
	</form>
	
	
	</div></div> 
	<div style="margin:20px;"class="panel panel-default col-md-3"><div class="panel-body">
	<center><span style="font-size:15px;">Search By Title </span></center><br>
	<form role="form" method="POST" action="index.php">
                     <input type="text" name="title" class="form-control"placeholder="Enter the title of Publication"/>       
				<br>
				<input type="submit"  value="Search" class="btn btn-primary btn-block"/>
    
	</form>
	
	
	</div></div> 
	<div style="margin:20px;"class="panel panel-default col-md-3"><div class="panel-body">
	<center><span style="font-size:15px;">Search By Author </span></center><br>
	<form role="form" method="POST" action="index.php">
                   <input type="text" name="author" class="form-control"placeholder="Enter the Name of Author"/>
				<br>
				<input type="submit"  value="Search" class="btn btn-primary btn-block"/>
    
	</form>
	
	
	</div></div> 
	<div style="margin:20px;"class="panel panel-default col-md-2"><div class="panel-body">
	<center><span style="font-size:15px;">Search By type </span></center><br>
	<form role="form" method="POST" action="index.php">
                            <select class="form-control" name="type">
                                <option selected>Research Paper</option>
                                <option >Artical</option>
                                <option>Journal</option>
                                <option >Conference Paper</option>
                                
                              </select>
							<br>
				<input type="submit"  value="Search" class="btn btn-primary btn-block"/>
    
	</form>
	
	
	</div></div> 
	
	</div><br>
	<table class="table table-striped">
    <thead>
      <tr>
			    <th>Sr.No</th>
                <th>Title</th>
				<th>Author</th>
				<th>Type</th>
				<th>Department</th>
                <th>Details</th>
                <th>See Reviews</th>
				<th>Upvote</th>
				<th>Comment</th>
				<th>Download</th>
                   
        </tr>
    </thead>
    <tbody>
     
		<?php
		if(isset($_POST["department"])){
	$department=$_POST["department"];
	$query="select * from publication where Department='$department'";
		}
		else if(isset($_POST["title"])){
			$title=$_POST["title"];
			$query="select * from publication where title='$title'";
			
		}
		else if(isset($_POST["author"])){
			$author=$_POST["author"];
			$query="select * from publication where author='$author'";
		}
		else if(isset($_POST["type"])){
			$type=$_POST["type"];
			$query="select * from publication where type='$type'";
			
		}
		else
		{
			$query="select * from publication where 1";
			
		}
	$result=mysql_query($query);
	$count=0;
	if(mysql_num_rows($result)>0){
	while($sql=mysql_fetch_assoc($result)){
	$count++;
	$ID=$sql["id"];
	$LDAP=$sql["LDAP"];
	$type=$sql["type"];
	$author=$sql["author"];
	$details=$sql["detail"];
	$department=$sql["department"];
	$upvote=$sql['upvote'];
	$title=$sql["title"];
	?>
	<tr>
			    <td><?php echo $count;?></td>
                   <td><?php echo $title;?></td>
				   <td><?php echo $author;?></td>
				   <td><?php echo $type;?></td>
                   <td><?php echo $department;?></td>
                   <td><?php echo $details;?></td>
                    
				<td>
				
                <form action="seereviews.php" method ="POST">
				      <input type="hidden" name="title"value="<?php echo $title;  ?>">
				      <input type="hidden" name="author"value="<?php echo $author;  ?>">
				      <input type="hidden" name="type"value="<?php echo $type;  ?>">
				      
				      <input type="submit" value="See reviews" class="btn btn-info">
				</form>


                  </td>
				<td>
				
				<form action="upvote.php" method ="POST">
				      <input type="hidden" name="title"value="<?php echo $title;  ?>">
				      <input type="hidden" name="author"value="<?php echo $author;  ?>">
				      <input type="hidden" name="type"value="<?php echo $type;  ?>">
				     
				      <button type="submit" value="Upvote" class="btn btn-info">Upvote<span class="badge"><?php  echo $upvote; ?></span></button>
				</form>
				</td>
				<td><?php if($login==1){?>
				<form action="comment.php" method ="POST">
				      <input type="hidden" name="title"value="<?php echo $title;  ?>">
				      <input type="hidden" name="author"value="<?php echo $author;  ?>">
				      <input type="hidden" name="type"value="<?php echo $type;  ?>">
				      
				      <input type="submit" value="Comment" class="btn btn-info">
				</form><?php }
				else{?>
					<input type="button" value="Comment" disabled data-toggle="tooltip" data-placement="top" title="Only the Registered Users Can Comment!"class="btn btn-info">
				<?php
				}
				?></td>
				<td>
				      <?php echo"<a href='getfile.php?id={$ID}'>Download</a>"?>
				</td>
                   
        </tr>
	
	<?php
	
	}
}

?>
</tbody>
  </table>
</body>
</html>
