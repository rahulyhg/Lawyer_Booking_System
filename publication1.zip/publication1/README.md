# Legistify Lawyer Booking System
*************************************************************************************************************************************
1)Software requirements : xampp
2)Install xampp and start apache and mysql servers.
3)Go to the htdocs folder in xampp and make a new directory publication1 where the website files will be stored.
4)Clone the files into that folder.

***************************************************************************************************************************************

1).The database with the name publication3 is to be made containing tables with 
names 
      A. Regiter(for the Details about the login)   
      B. Publication(Details about the publication made by users)   
      C. Comment(All The comments on the publication )
      D. Profile(Profile Details of the user who is registered)	  
2). Import the file publication3.sql to your database named as publication3  
3). Now open any browser and to start the main or first page for users write localhost/publication1/ and you can navigate from this page accordingly.
4)For seeing the changes in the database type localhost/phpmyadmin in a new tab which opens all the databases.

****************************************************************************************************************************************
