<?php
require "connect.inc.php";
session_start();
if(@$_SESSION['login']){
header("Location: admin.php");	
}

if($_SERVER["REQUEST_METHOD"] == "POST")
{
// username and password sent from form 

$myusername=addslashes($_POST['ldap']); 
$mypassword=addslashes($_POST['password']); 


$sql="SELECT ID FROM register WHERE LDAP='$myusername' and Password='$mypassword'";
$result=mysql_query($sql);
$count=mysql_num_rows($result);
if($count==1)
{
 //session_register("myusername");
 $_SESSION['login']=1;
$_SESSION['login_user']=$myusername;
header("location: admin.php");
}
else 
{
echo"<script>alert('Username and password are not matching');</script>";

}

}  
?>
<!DOCTYPE html>
<html>
<head>
	<title>Forgot Password</title>
	<link rel="stylesheet" href="normalize.css">
	<link rel="stylesheet" href="style.css">
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
<div style="height:35px;font-size:25px;vertical-align:middle;background-color:black;color:white;text-align:center;">
 <a href="index.php" style="text-decoration:none;color:white;">Publication Management System</a>
</div>
	<a href="index.php"> <img style='vertical-align:middle;width:80px ;margin:20px;' src='images/D.gif'></a>
<div style='vertical-align:middle; display:inline;font-size:30px;color:white;'>
<strong>IIT JODHPUR</strong>
</div>
	<section class="loginform cf" style=" margin-top:100px;">
		<strong>Do You Remember Profile(Secondary) Password</strong><br><br>
		<form action="forgotpassword.php">
		<button type="submit" class="btn btn-info " style="padding:6px 25px;margin:10px;">yes</button>
		<button type="button" class="btn btn-info" style="padding:6px 25px;" data-toggle="modal" data-target="#myModal">No</button>
		</form>
		

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog ">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Enter Your LDAP And Email Id</h4>
        </div>
        <div class="modal-body">
          <form action="sendmail.php" method="POST">
		     <br><input type="text" required name="Ldap"placeholder="LDAP">
			 <input type="text" required name="Email1"placeholder="Email">
		     <input type="submit">
		  
		  </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
		
	</section>
</body>
</html>
