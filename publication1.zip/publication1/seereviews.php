<?php
require "connect.inc.php";
if(isset($_POST["title"])&&isset($_POST["author"])&&isset($_POST["type"]))
{
	$title=$_POST["title"];
	$author=$_POST["author"];
	$type=$_POST["type"];

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Comments</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="index.php">Publication Management System</a>
    </div>
    <ul class="nav navbar-nav">
      <li ><a href="index.php">Home</a></li>
      
    </ul>
  </div>
</nav>
<div style="width:80%;margin:5% 10%;">
<center><h1>All Comments On This Paper</h1></center><br><br>
<table role="table" class="table table-striped table-bordered">
<thead>
<tr>
<th>Title</th>
<th>Author</th>
<th>Type</th>



</tr>

</thead>
<tbody>
<tr>
<td><?php  echo $title; ?></td>
<td><?php  echo $author; ?></td>
<td><?php  echo $type; ?></td>

</tr>


</tbody>


</table>



	<table class="table table-striped">
    <thead>
      <tr>
        <th>Sr.No </th>
        <th>LDAP</th>
        <th>Comments</th>
      </tr>
    </thead>
    <tbody>
	<?php
	   $query="select LDAP,comment from comment where title='$title' and author='$author' and type='$type'";
	   if($result1=mysql_query($query))
	   {
		   $count1=0;
		   while($a=mysql_fetch_assoc($result1))
		   {
			   $count1++;
			   $LDAP1=$a["LDAP"];
			   $comment=$a["comment"];
			   ?>
			   <tr>
        <td><?php echo $count1;?></td>
        <td><?php  echo $LDAP1;?></td>
        <td><?php  echo $comment; ?></td>
      </tr>
			   
			   <?php
			   
		   }
		   
	   }
	   else 
		   echo mysql_error();
	?>
      
      
    </tbody>
  </table>
	<?php
}

?></div></body></html>