<?php
// Check if a file has been uploaded
require "connect.inc.php";
session_start();
$user_check=$_SESSION['login_user'];
if($_SERVER["REQUEST_METHOD"] == "POST")
{

$id=$_POST['id'];
$type=$_POST['type']; 
$author=$_POST['author'];

$detail=$_POST['publication']; 
$title=$_POST['title'];
$user_check=$_SESSION['login_user'];

	
// Check if a file has been uploaded
if(isset($_FILES['papers'])) {
    // Make sure the file was sent without errors
    if($_FILES['papers']['error'] == 0) {
        // Connect to the database
        
 
        // Gather all required data
        $filename = mysql_real_escape_string($_FILES['papers']['name']);
       
        $data = mysql_real_escape_string(file_get_contents($_FILES  ['papers']['tmp_name']));
 
 
$sql="UPDATE `publication` SET `id`='$id',`LDAP`='$user_check',`type`='$type',`author`='$author',`detail`='$detail',`title`='$title',`data`='$data',`filename`='$filename' WHERE id='$id' and LDAP='$user_check'";
$result=mysql_query("select * from publication where LDAP='$user_check' and id='$id'");
if(mysql_num_rows($result)==0){
	echo "<script> alert('ID do not Match with Any of Your Publication');</script>";
			   header( "refresh:0;url=admin.php" );
	
}
else{
$result6=mysql_query($sql);
echo "<script> alert('Succesfully Updated');</script>";
			   header( "refresh:0;url=admin.php" );
}


    }
 
}
 
// Echo a link back to the main page

 
 	

}
