<?php
require "connect.inc.php";
if(isset($_POST['Email1'])&&isset($_POST['Ldap']))
{
	$LDAP1=$_POST['Ldap'];
	$Email1=$_POST['Email1'];
	$query="select Email from profile where LDAP='$LDAP1'";
	$result=mysql_query($query);
	if(mysql_num_rows($result)==0){
		echo "<script>alert('Please Contact Admin Because your Email is not Registered');</script>";
		header("refresh:0;url=forgot.php");
	}
	$Email=mysql_result($result,'0');
	if($Email!=$Email1){
		echo "<script>alert('Email is not Matching');</script>";
		header("refresh:0;url=forgot.php");
	}
	else{
		
$to      = $Email;
$subject = 'Forgot Password Link';
$message = 'Your Forgot passowrd is succesful';
$headers = 'From: webmaster@example.com' . "\r\n" .
    'Reply-To: webmaster@example.com' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();

mail($to, $subject, $message, $headers);
 echo "<script>alert('Password Link  has Sent to Your Mail Id Please Check Your Mail Id ');</script>";
		header("refresh:0;url=login.php");
		
	}
}


?>