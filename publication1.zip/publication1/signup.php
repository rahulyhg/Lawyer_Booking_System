<?php
require "connect.inc.php";
if(isset($_POST['LDAP'])&&isset($_POST['Password'])&&isset($_POST['profile_password'])){
$LDAP=$_POST["LDAP"];
$Password=$_POST["Password"];
$Profile_password=$_POST["profile_password"];

$query="select LDAP from register where LDAP='$LDAP'";
$result=mysql_query($query);
if(mysql_num_rows($result)==1)
{
	echo"<script>alert('This LDAP is not Available Plsease try another one')</script>";
	
	
}
else{
	
	$query="insert into register(id,LDAP,Password,profile_password) values ('','$LDAP','$Password','$Profile_password')";
	mysql_query($query);
	echo "<script>alert('Sign Up Succesful Now you Can Login');</script>";
	header("refresh:0;url=login.php");
}}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Sign Up Form</title>
	<link rel="stylesheet" href="normalize.css">
	<link rel="stylesheet" href="style.css">
</head>
<body>
<div style="height:35px;font-size:25px;vertical-align:middle;background-color:black;color:white;text-align:center;">
 <a href="index.php" style="text-decoration:none;color:white;">Publication Management System</a>
</div>


	 <a href="index.php"><img style='vertical-align:middle;width:80px ;margin:20px;' src='images/D.gif'></a>
<div style='vertical-align:middle; display:inline;font-size:30px;color:white;'>
<strong>IIT JODHPUR</strong>
</div>
	<section class="loginform cf" style=" margin-top:100px;">
		<form name="login" action="signup.php" method="POST" accept-charset="utf-8">
			<ul>
				
				<li>
					<label for="ldap">LDAP</label>
					<input type="text" id="ldap"name="LDAP" placeholder="LDAP" required></li>
					<li>
					<label for="password">Password</label>
					<input type="password" id="password" name="Password" placeholder="Password" required></li>
				<li><br>
					<label for="usermail">Profile Password</label>
					<input type="password" id="usermail" name="profile_password" placeholder="Secondary Password" required>
				</li>
				
				<li><br>
					<input type="submit" value="Sign Up">
				</li>
				
			</ul>
		</form>
	</section>
</body>
</html>
