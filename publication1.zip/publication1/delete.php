<?php
require "connect.inc.php";

$title=$_POST["title"];
$author=$_POST["author"];
$type=$_POST["type"];
$related=$_POST["related"];
$query="delete from publication where title='$title' and author='$author' and type='$type'";
$result=mysql_query($query);
echo "<script>alert('Successfully Deleted');</script>";
header( "refresh:0;url=admin.php" );




?>