<?php

include("config.php");	
$con = mysqli_connect("localhost","root","","publication3");
session_start();


if($_SERVER["REQUEST_METHOD"] == "POST")
{
// username and password sent from form 

$myusername=addslashes($_POST['profilepassword']); 
$mypassword=addslashes($_POST['password']); 


$sql="SELECT ID FROM register WHERE profile_password='$myusername'";
if($result=mysqli_query($con,$sql))
{
$count=mysqli_num_rows($result);

//echo "$count";
// If result matched $myusername and $mypassword, table row must be 1 row


if($count==1)
{
 //session_register("myusername");
 $sql="UPDATE `register` SET `Password`='$mypassword' WHERE profile_password='$myusername'";
 $result=mysqli_query($con,$sql);
 echo "<script>alert('Password Changed Succesfully Please login now');</script>";
 header("refresh:0;url=login.php");
//$row=mysql_fetch_array($result);
//$active=$row['active'];
 
}
else 
{
echo"<script>alert('Profile Password Don\'t Matching');</script>";

}
}
else{
	
}
}  
?>
<!DOCTYPE html>
<html>
<head>
	<title>Forgot Password</title>
	<link rel="stylesheet" href="normalize.css">
	<link rel="stylesheet" href="style.css">
</head>
<body><div style="height:35px;font-size:25px;vertical-align:middle;background-color:black;color:white;text-align:center;">
 <a href="index.php" style="text-decoration:none;color:white;">Publication Management System</a>
</div>
	 <a href="index.php"><img style='vertical-align:middle;width:80px ;margin:20px;' src='images/D.gif'></a>
<div style='vertical-align:middle; display:inline;font-size:30px;color:white;'>
<strong>IIT JODHPUR</strong>
</div>
	<section class="loginform cf" style=" margin-top:100px;">
		<form name="login" action="forgotpassword.php" method="POST" accept-charset="utf-8">
			<center><h3>Forgot Password Form</h3></center>
			<ul>
				
				<li>
					<label for="password"><strong>LDAP</strong></label>
					<input type="text" name="LDAP" placeholder="LDAP" required></li>
					<li>
					<label for="password"><strong>Profile Password</strong></label>
					<input type="text" name="profilepassword" placeholder="Profile password" required></li>
				<li><br>
					<label for="usermail"><strong>New Login Password</strong></label>
					<input type="password" name="password" placeholder="New Login password" required>
				</li>
				
				<li><br>
					<input type="submit" value="Change Password">
				</li>
				
			</ul>
		</form>
	</section>
</body>
</html>
