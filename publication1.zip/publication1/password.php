<?php
// Check if a file has been uploaded

require "connect.inc.php";
session_start();
$user_check=$_SESSION['login_user'];
if($_SERVER["REQUEST_METHOD"] == "POST")
{

$password=$_POST['password'];
$new_password=$_POST['new_password']; 
$confirm_password=$_POST['confirm_password'];

$user_check=$_SESSION['login_user'];

	

 
 
$sql="SELECT `Password` FROM `register` WHERE LDAP='$user_check'";

$result = mysql_query($sql);

$row = mysql_fetch_assoc($result);
if($row['Password']==$password && $new_password==$confirm_password)
{
$sql="UPDATE `register` SET `Password`='$new_password' WHERE LDAP='$user_check'";
$result = mysql_query($sql);
echo "<script>alert('Successfully Updated Password');</script>";
header("refresh:0;url=admin.php");
}
else
{
	echo "<script>alert('Please Enter Same Password in both the fields');</script>";
	header("refresh:0;url=admin.php");
}



    }
 
    // Close the mysql connection
    


 
// Echo a link back to the main page

 
 	
?>