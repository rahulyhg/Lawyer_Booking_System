<?php
// Check if a file has been uploaded

require "connect.inc.php";


session_start();

if($_SERVER["REQUEST_METHOD"] == "POST")
{


$Name=$_POST['name']; 
$Department=$_POST['department'];

$Detail=$_POST['detail']; 
$Mobile=$_POST['mobile'];

$Email=$_POST['email']; 
$Address=$_POST['address']; 
$Research=$_POST['research']; 

$user_check=$_SESSION['login_user'];

// Make sure the file was sent without errors
    if($_FILES['cv']['error'] == 0) {
       
 
        // Gather all required data
        $filename = mysql_real_escape_string($_FILES['cv']['name']);
        $data = mysql_real_escape_string(file_get_contents($_FILES  ['cv']['tmp_name']));
 
        // Create the SQL query
	
$sql8="UPDATE `profile` SET `Address`='$Address',`Department`='$Department',`LDAP`='$user_check',`Detail`='$Detail',`Email`='$Email',`Mobile`='$Mobile',`Name`='$Name',`Research`='$Research',`Data`='$data',`filename`='$filename'  WHERE LDAP='$user_check'";

$result6=mysql_query($sql8);
 if(! $result6 ) {
               die('Could not insert... data because for this ldap data already exist u can update data using update link : ' . mysql_error());
            }
}
 

}

// Echo a link back to the main page
echo '<script>alert("Succesfully Updated");</script>';
header("refresh:0;url=admin.php");
?>
 