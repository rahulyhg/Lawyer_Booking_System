<?php
if(isset($_POST['ID'])&&isset($_POST['author'])&&isset($_POST['publication'])&&isset($_POST['title'])){
$ID=$_POST['ID'];
$author=$_POST['author'];
$publication=$_POST['publication'];
$title=$_POST['title'];


?>

<!DOCTYPE html>
<html>
<head>
<title>
Update Publication

</title>
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>

            	<div style="margin:10% 20% 0 20%;">
                
                  <form class="form" action="publicationUpdate.php" method="post" enctype="multipart/form-data" id="registrationForm">
				  
				    <div class="form-group">
                          <div class="col-xs-6">
                            <label for="acccount_number"><h4>Type of Publication</h4></label>
							
                              <select name ="type" class="form-control">
							      <option selected>Type of Publication</option>
								  <option >Research Paper</option>
								  <option >Artical</option>
								  <option >Journal</option>
								  <option >Conference Paper</option>
							  </select>
                          </div>
                      </div>
				  
				  
				     <div class="form-group">
                          
                          <div class="col-xs-6">
                              <label for="payee_name"><h4>ID</h4></label>
                              <input type="text"  class="form-control" disabled name="id" id="payee_name" required value ="<?php  echo $ID; ?>" placeholder="Id of publication" title="id">
                          </div><input type="hidden"  class="form-control" name="id" id="payee_name"  required value ="<?php  echo $ID; ?>" placeholder="Id of publication" title="id">
                      </div>
					  
                      
                      <div class="form-group">
                          <div class="col-xs-6">
                            <label for="acccount_number"><h4>Author</h4></label>
                              <input type="text" class="form-control" name="author" value="<?php echo $author;  ?>" id="author" placeholder="Name of Author" required title="Account number">
                          </div>
                      </div>
					  
          
                      <div class="form-group">
                          
                          <div class="col-xs-6">
                               <label for="bank_name"><h4> Additional Information for Publication</h4></label>
                              <input type="text" class="form-control" value="<?php  echo $publication; ?>" name="publication" id="bank_name" placeholder="Information" required title="Bank Name">
                          </div>
                      </div>
          
                      <div class="form-group">
                          <div class="col-xs-6">
                             <label for="branch_name"><h4>Title</h4></label>
                              <input type="text" value="<?php  echo $title;?>"class="form-control" name="title" id="branch_name"  required placeholder="Title" title="enter your Branch Nname">
                          </div>
                      </div>
                      <div class="form-group">
                          
                          <div class="col-xs-6">
                              <label for="ifsc_code"><h4>Upload paper</h4></label>
                              <input type="file" accept="application/pdf"  class="form-control"  required name="papers" id="paper" placeholder="Upload paper">
                          </div>
                      </div>
                   
                      <div class="form-group">
                           <div class="col-xs-12" style="padding-bottom:10%;">
                                <br>
                              	<button class="btn btn-lg btn-success" type="submit"><i class="glyphicon glyphicon-ok-sign"></i> Update Publication</button>
                               	<button class="btn btn-lg" type="reset"><i class="glyphicon glyphicon-repeat"></i> Reset</button>
                            </div>
                      </div>
              	</form>
              </div>
			  
			  
</body>
	<?php
}
else{
	echo "<script>alert('There Is Some Error In the Way !!!');</script>";
	header("refresh:0;url=admin.php");
	
}
?>	
 </html>