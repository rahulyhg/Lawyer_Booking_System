<?php
session_start();

require "connect.inc.php";
if($_SESSION["login1"]==1)
{
	header("Location: admin_see_request.php");
}
else{
if(isset($_POST["uid"])&&isset($_POST["pwd"]))
{
	if(!empty($_POST["uid"])&&!empty($_POST["pwd"]))
	{    
       $uid=$_POST["uid"];
	   $pwd=$_POST["pwd"];
	   $query="select id from admin_table where username='$uid' and password='$pwd'";
	   if($result=mysql_query($query))
	   {
		   if(mysql_num_rows($result)==1)
		   {
			   $id=mysql_result($result,'0');
			   $_SESSION["login1"]=1;
			   $_SESSION["id"]=$uid;
			   
			   header("Location: admin_see_request.php");
		   }
		   else{
			   echo "<script>alert('invalid username and password combination')</script>";
		   }
		   
	   }
	   else echo mysql_error();
	}
	else{
		
	echo "<script> alert('All Fields Are Required');
</script>"	;
header("Location: user_start.php");
}
	
}





}
?>


<!doctype html>
<html lang="en-US">
<head>

	<meta charset="utf-8">

	<title>Lawyer Legistify</title>

	<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Varela+Round">
	<link rel="stylesheet"  href="css/admin_style.css">

	<style>
			body {
						background: #e1c192 url(images/pic06.jpg);
			}
		</style>
</head>
<body>
	<div id="login">
		<h2><span class="fontawesome-lock"></span>Lawyer Login</h2>
		<form method="POST" name="form1" onsubmit="return validateForm()" action="admin.php" enctype="multipart/form-data" >

			<fieldset>
				<p><label for="user_id">User Id</label></p>
				<p><input type="text" id="user_id" name="uid"></p> 
				<div id ="valid_user_id" ></div>

				<p><label for="user_password">Password</label></p>
				<p><input type="password" id="user_password" value="" name="pwd"></p> 
				<div id ="valid_password" ></div>

				<p><input type="submit" value="Sign In"></p>
			</fieldset>
		</form>
	</div> 
	<script language="javascript">
	
    // var x = document.getElementById("input");
    // x.onclick = function() {validateForm()};
     var defaultColor = document.getElementById("demail").style.borderColor;

    function validateForm() {
    	flag = true;
    if (document.getElementById("user_password").value == null || document.getElementById("user_password").value == "") {
        document.getElementById("valid_password").innerHTML = "Please Enter Password";
        document.getElementById("user_password").style.borderColor = 'red';
        console.log("error");
        flag = false;
    }

    if (document.getElementById("user_id").value == null || document.getElementById("user_id").value == "") {
        document.getElementById("valid_user_id").innerHTML = "Please Enter User Id";
        document.getElementById("user_id").style.borderColor = 'red';
        console.log("error");
        flag = false;
    }      

    return flag;
      }

</script>

</body>	
</html>