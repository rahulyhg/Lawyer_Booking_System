<?php 
session_start();

require "connect.inc.php";

if(isset($_POST["uid"])&&isset($_POST["pwd"]))
{
	if(!empty($_POST["uid"])&&!empty($_POST["pwd"]))
	{    
       $uid=$_POST["uid"];
	   $pwd=$_POST["pwd"];
	   $query="select id from registered_user where user_id='$uid' and password_hash='$pwd'";
	   if($result=mysql_query($query))
	   {
		   if(mysql_num_rows($result)==1)
		   {
			   $_SESSION["login"]=1;
			   echo "successfully login";
		   }
		   else{
			   header("Location: user_start.php");
		   }
		   
	   }
	   else echo mysql_error();
	}
	else{
		
	echo "<script> alert('All Fields Are Required');
</script>"	;
header("Location: user_start.php");
}
	
}



?>