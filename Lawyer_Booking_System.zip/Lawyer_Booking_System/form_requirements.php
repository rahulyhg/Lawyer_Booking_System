<?php
session_start();
$ui=$_SESSION["ui"];
if($_SESSION["login"]!=1)
{
		header("Location:user_start.php");

}	
 
require "connect.inc.php";

if(isset($_POST["name"])&&isset($_POST["phone_no"])&&isset($_POST["email_id"])&&isset($_POST["age"])&&isset($_POST["meetingdate"])&&isset($_POST["lawyer_id"]))
{
	if(!empty($_POST["name"])&&!empty($_POST["phone_no"])&&!empty($_POST["email_id"])&&!empty($_POST["age"])&&!empty($_POST["meetingdate"])&&!empty($_POST["lawyer_id"]))
	{    
        $name=$_POST["name"];
        $phone_no=$_POST["phone_no"];
        $email_id=$_POST["email_id"];
        $age=$_POST["age"];
        $meeting=$_POST["meetingdate"];
        $lawyer_id=$_POST["lawyer_id"];
	    
		$query="insert into meeting(id,user_id,name,phone_no,email_id,age,meetingdate,lawyer_id) 
		values('','$ui','$name','$phone_no','$email_id','$age','$meeting','$lawyer_id')";
		if($result=mysql_query($query))
		{
			echo "<script>alert('Your Request is sent to the Lawyer')</script> ";
			
		}
		else{
			echo mysql_error();
			
		}
	}
	else{
		
	echo "<script> alert('All Fields Are Required');
</script>"	;
}
	
}




?>

<!DOCTYPE html>
<html lang="en">
    <head>
		<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
		<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <title>Legistify</title>
        
        <link rel="stylesheet" type="text/css" href="css/style1.css" />
        <script src="js/modernizr.custom.63321.js"></script>
      
<style>
			body {
				background: #e1c192 url(images/bg3.jpg);
				-webkit-background-size: cover;
				  -moz-background-size: cover;
				  -o-background-size: cover;
				  background-size: cover;
			}
		</style>
		
    </head>
    <body>



        <div class="container">
			<header>
				<h1 style="color: black;"><strong>Lawyer Booking form</strong> </h1>
				<h2 style="color: black;">Users Side</h2>
			</header>
			<!-- Trigger the modal with a button -->
<center><button type="button" class="btn btn-info" data-toggle="modal" data-target="#myModal">Progress Request</button></center>

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">Progress Of Your Request
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"></h4>
      </div>
      <div class="modal-body">
        <table class="table table-striped">
    <thead>
      <tr>
        <th>lawyer Id</th>
        <th>Meeting date</th>
        
        <th>Status</th>
      </tr>
    </thead>
    <tbody>
   <?php 
          $query="select * from meeting where user_id='$ui'";
		  if($result=mysql_query($query))
{
while($sql_name = mysql_fetch_array($result)){
		  $lawyer_id=$sql_name["lawyer_id"];
		  $meetingdate=$sql_name["meetingdate"];
		  $accepted=$sql_name["accepted"];
		  $deny=$sql_name["deny"];
		  if($accepted==0&&$deny==0)
		  {?>
			  <tr>
                  <td><?php echo $lawyer_id;?></td>
                  <td><?php echo $meetingdate;?></td>
                  
                  <td>Processing</td>
             </tr>
		  <?php
		  }
		  else if($accepted==0&&$deny==1)
		  {?>
			  <tr>
                  <td><?php echo $lawyer_id;?></td>
                  <td><?php echo $meetingdate;?></td>
                  
                  <td>Denied</td>
             </tr>
		  <?php
		  }
		  else 
		  {
			  ?>
			  <tr>
                  <td><?php echo $lawyer_id;?></td>
                  <td><?php echo $meetingdate;?></td>
                  
                  <td>Accepted</td>
             </tr>
		  <?php
		  }

}
}
   ?>   

	 
      
    </tbody>
  </table>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
			<section class="main">
				<form class="form-2" method="POST" name="form1" onsubmit="return validate()" action="form_requirements.php"  >
					<h1><span class="log-in">Your Details</span></h1>
					<p class="float">
						<label for="login">name</label>
						<input type="text" name="name" placeholder="Name">
					</p>
					

					<p class="float">
						<label for="login">Phone No.</label>
						<input type="text" name="phone_no" >
					</p>
					<p class="float">
						<label for="password">Email Id</label>
						<input type="text" name="email_id" >
					</p>
                    <p class="float" style="margin-bottom: 20px";>
						<label for="login">Age</label>
						<input type="number" name="age" placeholder="">
					</p>
					
					<p class="float">
						<label for="password">User id of lawyer</label>
						<input type="text" name="lawyer_id" >
					</p>

					

					
					<p class="float" >
						<label for="login">Gender</label>
						<select name = "gender[]" style=" font-family: 'Lato', Calibri, Arial, sans-serif;
    font-size: 13px;
    font-weight: 400;
    display: block;
    width: 100%;
    padding: 5px;
    margin-bottom: 5px;
    border: 3px solid #ebe6e2;
    border-radius: 5px;
    -webkit-transition: all 0.3s ease-out;
    -moz-transition: all 0.3s ease-out;
    -ms-transition: all 0.3s ease-out;
    -o-transition: all 0.3s ease-out;
    transition: all 0.3s ease-out;">
						<option selected>Male</option>
						<option>Female</option> 
						</select>
					</p>
					<p class="float">
						<label for="login">Date of meeting</label>
						<input type="date" name="meetingdate" >
					</p>
					<p style="margin-bottom: 400px;"></p>
					
					

					
					
					<p class="clearfix"> 
						<input type="submit" value="Book">
						<a href="logout_user.php" class="log-twitter">Logout</a>    
						
					</p>
					
				</form>​​
			</section>
			
        </div>
		<!-- jQuery if needed -->
        <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
		<script type="text/javascript">
			

			function validate() {
		var myform = document.forms["form1"];
		//formName being the name of the form
		for (i = 0; i < myform.length; i++) {
			inp= myform.elements[i];
			if(inp.type=="text" || inp.type=="password") {
				if (inp.value.length == 0){
						if (inp.name=="name[]") {
							alert("Please enter the name of guest");
						} else if (inp.name=="age[]") {
							alert("Please enter the age of guest");
						} 
						} else {
							alert("Please enter value in field : " + inp.name);
						}
					return false;
				}
			}
		}
	}
		</script>
    </body>
</html>