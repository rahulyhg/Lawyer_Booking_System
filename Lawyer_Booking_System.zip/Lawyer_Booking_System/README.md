# Legistify Lawyer Booking System
*************************************************************************************************************************************
1)Software requirements : xampp
2)Install xampp and start apache and mysql servers.
3)Go to the htdocs folder in xampp and make a new directory (legistify) where the website files will be stored.
4)Clone the files into that folder.

***************************************************************************************************************************************

1).The database with the name legistify1 is to be made containing tables with 
names 
      A. admin_table(for the Details about the Lawyer)   
      B. registered_user(Details about the user)   
      C. Meeting(Details about the meeting and booking of lawyer )	  
2). Import the file legistify1.sql to your database named as legistify1  
3). Now open any browser and to start the main or first page for users write localhost/legistify/ and you can navigate from this page accordingly.
4)For seeing the changes in the database type localhost/phpmyadmin in a new tab which opens all the databases.

****************************************************************************************************************************************
