<?php
     session_start();
     require "connect.inc.php";
     $id=$_SESSION["id"];
?>
<!Doctype html>
<html>
<head>
		<meta charset='UTF-8'>
	    <title>Lawyer See Request</title>
	    <meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" href="css/styletable.css">
	    <link rel="stylesheet"  href="css/admin_style.css">
	    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Varela+Round">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" >
	
	<!--[if !IE]><!-->
	<style>
			body {
				     background: #e1c192 url(images/bg3.jpg);
				    -webkit-background-size: cover;
				    -moz-background-size: cover;
				    -o-background-size: cover;
				    background-size: cover;
			     }
		
	
	       @media 
	      only screen and (max-width: 760px),
	     (min-device-width: 768px) and (max-device-width: 1024px)  {
		                   table, thead, tbody, th, td, tr { 
			                                                display: block; 
		                                                   }
		
		
		  thead tr { 
			         position: absolute;
			         top: -9999px;
			         left: -9999px;
		           }
		
		       tr { 
			         border: 1px solid #ccc; 
				   }
		
		td { 
			/* Behave  like a "row" */
			border: none;
			border-bottom: 1px solid #eee; 
			position: relative;
			padding-left: 50%; 
		}
		
		td:before { 
			/* Now like a table header */
			position: absolute;
			/* Top/left values mimic padding */
			top: 6px;
			left: 6px;
			width: 45%; 
			padding-right: 10px; 
			white-space: nowrap;
		}
		
		/*
		Label the data
		*/
		td:nth-of-type(1):before { content: "First Name"; }
		td:nth-of-type(2):before { content: "Last Name"; }
		td:nth-of-type(3):before { content: "Job Title"; }
		td:nth-of-type(4):before { content: "Favorite Color"; }
		td:nth-of-type(5):before { content: "Wars of Trek?"; }
		td:nth-of-type(6):before { content: "Porn Name"; }
		td:nth-of-type(7):before { content: "Date of Birth"; }
		td:nth-of-type(8):before { content: "Dream Vacation City"; }
		td:nth-of-type(9):before { content: "GPA"; }
		td:nth-of-type(10):before { content: "Arbitrary Data"; }
	}
	
	/* Smartphones (portrait and landscape) ----------- */
	@media only screen
	and (min-device-width : 320px)
	and (max-device-width : 480px) {
		body { 
			padding: 0; 
			margin: 0; 
			width: 320px; }
		}
	
	/* iPads (portrait and landscape) ----------- */
	@media only screen and (min-device-width: 768px) and (max-device-width: 1024px) {
		body { 
			width: 495px; 
		}
	}
	
	</style>

</head>
<body>

<script>
function myFunction() {
    alert("Invalid Credentials Please Login Again");
}

</script>
<p style = "margin-top:5%"></p>
<div id="login" style>
<center><h1>Welcome <?php echo $id;?></h1></center>
<h2><span class="fontawesome-lock"></span>Lawyer Meeting Request</h2>

</div>
<?php

if($_SESSION["login1"]!=1)
{
		header("Location:admin.php");

}	
?>
<table class="table table-striped">
    <thead>
	<tr>
        <th>Name of user</th>
        <th>Phone Number</th>
        <th>Email Id</th>
        <th>Meeting Date</th>
        <th>Accept Request</th>
        <th>Denial Request</th>
      </tr>
    </thead>
    <tbody>
      <?php
	  $query="SELECT name,phone_no,email_id,meetingdate from meeting where lawyer_id='$id' and accepted='0' and deny='0'";
if($result=mysql_query($query))
{
while($sql_name = mysql_fetch_array($result)){
$name=$sql_name["name"];
$phone=$sql_name["phone_no"];
$email=$sql_name["email_id"];
$meeting=$sql_name["meetingdate"];
	  ?>
	  
      
	  
	  <tr>
        <td><?php echo $name;?></td>
        <td><?php echo $phone;?></td>
        <td><?php echo $email;?></td>
        <td><?php echo $meeting;?></td>
		<form method="POST" action="requestaccept.php">
		<input type="hidden" value="<?php echo $name;?>" name="name">
		
        <td><input type="submit" class="btn btn-primary" value="Accept"></td>
		</form>
		<form method="POST" action="requestdeny.php">
		<input type="hidden" value="<?php echo $name;?>" name="name">
		
        <td><input type="submit" class="btn btn-primary" value="Deny"></td>
		</form>
        
      
	  </tr>
<?php
}
}

?>
     
    </tbody>
  </table>
	

<div id="login">
<p style = "margin-top: 5%;"> </p>
<center>
		<p style = "margin-top: 5%;"> </p>
		<a href = "logout1.php" class = "btn btn-success">Logout</a>
		
</center>
		</div>
</body>
</html>

