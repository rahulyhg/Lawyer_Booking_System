<?php
   session_start();
   $_SESSION["login"]=0;
   
   
   echo 'You have cleaned session';
   header("Location:user_start.php");
?>