<?php
session_start();
require "connect.inc.php";

if($_SESSION["login1"]!=1)
{
	header("Location: admin.php");
	
}
else{
	$name=$_POST["name"];
	
	$ld=$_SESSION["id"];
	$query="UPDATE meeting SET deny=1 WHERE lawyer_id='$ld' and name='$name'";
    $result=mysql_query($query);
	
	$query="select email_id from meeting where lawyer_id='$ld' and name='$name'";
	$result=mysql_query($query);
	$sql_name = mysql_fetch_array($result);
	
	
	$to      = $sql_name["email_id"];
    $subject = 'regarding Lawyer Booking';
    $message = "Dear $name,<br> Your Request for lawyer booking is <strong>Denied</strong> due to some reason.
	<br>Thanks.";
    $headers = 'From: webmaster@example.com' . "\r\n" .
    'Reply-To: webmaster@example.com' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();

    mail($to, $subject, $message, $headers);
	header("Location: admin_see_request.php");
}




?>
