-- phpMyAdmin SQL Dump
-- version 4.4.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 08, 2016 at 03:45 PM
-- Server version: 5.6.25
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `legistify1`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_table`
--

CREATE TABLE IF NOT EXISTS `admin_table` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_table`
--

INSERT INTO `admin_table` (`username`, `password`, `id`) VALUES
('Shiv', 'dukati', 1),
('upendra', 'dukati', 2),
('kaushtubh', 'dukati', 3),
('vivek', 'dukati', 4);

-- --------------------------------------------------------

--
-- Table structure for table `meeting`
--

CREATE TABLE IF NOT EXISTS `meeting` (
  `id` int(11) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone_no` varchar(255) NOT NULL,
  `email_id` varchar(255) NOT NULL,
  `age` int(11) NOT NULL,
  `meetingdate` date NOT NULL,
  `lawyer_id` varchar(255) NOT NULL,
  `accepted` int(11) NOT NULL,
  `deny` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `meeting`
--

INSERT INTO `meeting` (`id`, `user_id`, `name`, `phone_no`, `email_id`, `age`, `meetingdate`, `lawyer_id`, `accepted`, `deny`) VALUES
(1, 'shiv', 'Shiv Bhagwan', '9462293768', 'ug201310030@iitj.ac.in', 20, '2016-02-04', 'shiv', 0, 0),
(2, 'shiv', 'Prakhar', '9465546425', 'ug201310029@iitj.ac.in', 21, '2016-03-05', 'shiv', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `registered_user`
--

CREATE TABLE IF NOT EXISTS `registered_user` (
  `id` int(11) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Phone_no` varchar(255) NOT NULL,
  `Password_hash` varchar(255) NOT NULL,
  `Address` varchar(255) NOT NULL,
  `Sex` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registered_user`
--

INSERT INTO `registered_user` (`id`, `user_id`, `Name`, `Phone_no`, `Password_hash`, `Address`, `Sex`, `email`) VALUES
(1, 'shiv', 'shiv bhagwan', '9462293768', '111', 'IIT Jodhpur', 'male', 'shiv@flipapisa.com'),
(2, 'vaibhav', 'vaibhav jain', '9413220603', '111', 'IIT Jodhpur', 'male', 'ug201312036@iitj.ac.in'),
(3, 'ramdev', 'ramdev choudhary', '9672413668', '111', 'IIT Jodhpur', 'male', 'ug201312028@iitj.ac.in');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_table`
--
ALTER TABLE `admin_table`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `meeting`
--
ALTER TABLE `meeting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registered_user`
--
ALTER TABLE `registered_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_table`
--
ALTER TABLE `admin_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `meeting`
--
ALTER TABLE `meeting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `registered_user`
--
ALTER TABLE `registered_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
