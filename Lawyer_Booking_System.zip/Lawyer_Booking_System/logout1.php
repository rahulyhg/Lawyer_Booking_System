<?php
   session_start();
   $_SESSION["login1"]=0;
   
   
   echo 'You have cleaned session';
   header("Location:admin.php");
?>