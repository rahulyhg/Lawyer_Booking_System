<!DOCTYPE html>

<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>Legistify</title>
		<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

	</head>
	<body style="background: url(<?php  echo base_url();?>/assets/images/bg3.jpg) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;">


		<!-- Banner -->
			
				<center style="margin-top:200px;"><h1>Legistify</h1>
				<h3>Lawyer Booking System</h3><br>
				
<br><br>			<a href="<?php  echo base_url()?>load/user_start"type="button" class="btn btn-primary btn-lg">User Login</a>
			
			<a href="<?php  echo base_url()?>admin/admin_start" type="button"  class="btn btn-primary btn-lg">Lawyer Login</a>

		</center>

		

		

	</body>
</html>