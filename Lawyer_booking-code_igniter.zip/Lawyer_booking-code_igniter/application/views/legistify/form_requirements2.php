</header></center>
        <div class="row" >
			<div class="col-md-4">
			
			</div>
			<div class="col-md-4 panel panel-default" >
			
			<!-- Trigger the modal with a button -->

			
				<form  method="POST" action="<?php  echo base_url()?>book/confirm"  >
					<center><h1>Booking Details</h1></center><hr>
					<div class="row"><p class="col-md-6">
						<label for="name">Name </label><br>
						<input type="text" required id="name" class="form-control" name="name" placeholder="Name">
					</p>
					

					<p class="col-md-6">
						<label for="phone_no">Phone No.</label><br>
						<input type="text" required id="phone_no" placeholder="Phone Number" class="form-control"name="phone_no" >
					</p>
					</div><br>
					<div class="row">
					<p class="col-md-6">
						<label for="Email_id">Email Id</label><br>
						<input type="text" required class="form-control" id="email_id" placeholder="Email Id"name="email_id" >
					</p>
                    <p class="col-md-6" style="margin-bottom: 20px";>
						<label for="age">Age</label><br>
						<input type="number" required  id="age" class="form-control"name="age" placeholder="Age">
					</p>
					</div><br>
					<div class="row">
					<p class="col-md-6">
						<label for="lawyer">User id of lawyer</label><br>
						<input type="text" required id="lawyer" class="form-control" placeholder="User Id of Lawyer" name="lawyer_id" >
					</p>					
					<p class="col-md-6" >
						<label for="gender">Gender</label><br>
						<select class="form-control" name = "gender" id="gender" >
						<option selected>Male</option>
						<option>Female</option> 
						</select>
					</p>
					</div><br>
					<div class="row">
					<p class="col-md-6">
						<label for="meetplace">Place of meeting</label><br>
						<input required type="text" id="meetplace" class="form-control"placeholder="Place Of Meeting" name="meetplace" >
					</p>
					<p class="col-md-6">
						<label for="meetdate">Date of meeting</label><br>
						<input type="date" id="meetdate"class="form-control" name="meetingdate" >
					</p>
					</div><br><br>
					<center>
					
						<input type="submit" class="btn btn-primary" style="padding:8px 40px;margin:0 10px;"value="Book">
					
					 
						<a class="btn btn-primary"style="padding:8px 40px;margin:0 10px;" href="<?php echo  base_url()?>load/user_logout" class="form-control">Logout</a>    
					
					</center>
					
				</form>​​
			
			
        </div></div>
		
    </body>
</html>