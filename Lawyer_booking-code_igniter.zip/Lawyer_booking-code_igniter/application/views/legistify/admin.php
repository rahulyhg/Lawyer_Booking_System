<!doctype html>
<html lang="en-US">
<head>

	<meta charset="utf-8">

	<title>Lawyer Login</title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

	<style>
			body {
						background: #e1c192 url(images/pic06.jpg);
			}
		</style>
</head>
<body>
<div class="row" >
<div class="col-md-4">
</div>
	<div class="col-md-4 panel panel-default" style="margin-top:150px;">
		<h2><span class="glyphicon glyphicon-log-in" ></span> Lawyer Login</h2><hr>
		<form method="POST"  onsubmit action="<?php echo base_url()  ?>admin/confirm" enctype="multipart/form-data" >

			<fieldset>
				<p><label for="user_id">User Id</label></p>
				<p><input required class="form-control"type="text" id="user_id" name="username"></p> 
				

				<p><label for="user_password">Password</label></p>
				<p><input required class="form-control"type="password" id="user_password"  name="password"></p> 
				
<br>
				<p><input class="btn btn-primary btn-block" type="submit" value="Sign In"></p>
			</fieldset>
		</form>
	</div> 
	
</div>

</body>	
</html>