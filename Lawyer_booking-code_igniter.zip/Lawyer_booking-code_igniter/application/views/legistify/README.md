# Legistify Lawyer Booking System
*************************************************************************************************************************************
1)Software requirements : xampp
2)Install xampp and start apache and mysql servers.
3)Go to the htdocs folder in xampp and make a new directory (ci) where the website files will be stored.
4)Clone the files into that folder.

***************************************************************************************************************************************

1).The database with the name ci is to be made containing tables with 
names 
      A. admin(for the Details about the Lawyer)   
      B. user(Details about the user)   
      C. meeting(Details about the meeting and booking of lawyer )	  
2). Import the file ci.sql to your database named as ci  
3). Now open any browser and to start the main or first page for users write localhost/ci/ and you can navigate from this page accordingly.
4)For seeing the changes in the database type localhost/phpmyadmin in a new tab which opens all the databases.

****************************************************************************************************************************************
