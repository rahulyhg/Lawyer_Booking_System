<?php foreach($users as $user){?>
<tr>
   <td><?php echo $user['name'];?></td>
   <td><?php echo $user['phone_no'];?></td>
   <td><?php echo $user['email_id'];?></td>
   <td><?php echo $user['meetplace'];?></td>
   <td><?php echo $user['meetingdate'];?></td>
   <td>
   <form method="post"action="<?php echo base_url()?>getuser1/accept">
   <input type="hidden" value="<?php echo $user['id']?>" name="id"/>
   <button type="submit" class="btn btn-primary">accept</button>
   </form>
   </td>
   <td>
   <form method="post" action="<?php echo base_url()?>getuser1/deny">
   <input type="hidden" value="<?php echo $user['id']?>" name="id">
   <button type="submit" class="btn btn-primary">Deny</button>
   </form>
   </td>
</tr>

<?php } ?>