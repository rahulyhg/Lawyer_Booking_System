 </tbody>
  </table>
	

<div id="login">
<p style = "margin-top: 5%;"> </p>
<center>
		<p style = "margin-top: 5%;"> </p>
		<a href = "<?php echo base_url()?>admin/admin_logout" class = "btn btn-success">Logout</a>
		
</center>
		</div>
</body>
</html>
