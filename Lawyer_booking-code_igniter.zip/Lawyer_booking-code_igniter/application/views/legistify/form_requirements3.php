<?php 
foreach($meetings as $meeting){?>

<tr>
        <td><?php echo $meeting['lawyer_id'];?></td>
        <td><?php echo $meeting['meetplace'] ;?></td>
        <td><?php  echo $meeting['meetingdate']  ;?></td>
        <td><?php
		$approve=$meeting['approve'];
		$accept=$meeting['accept'];
		$deny=$meeting['deny'];
		if($approve==0)
		{
			echo "Processing";
		}
		else{
			if($accept==1)
			{
				echo "Accepted";
			}
			else
				echo "Denied";
		}
?>		
		</td>
      </tr>
<?php }?>
    </tbody>
  </table>
        
      </div>
      <div class="modal-footer" style="background-color:#428bca;">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>