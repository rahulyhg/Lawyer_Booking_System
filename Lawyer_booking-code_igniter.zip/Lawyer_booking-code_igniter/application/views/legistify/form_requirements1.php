
<button type="button" class="btn btn-info" data-toggle="modal" data-target="#myModal">See Status </button><br><br>

<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header" style="background-color:#428bca;color:white;">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Progress Of Your Request</h4>
      </div>
      <div class="modal-body">
	  <table class="table table-striped">
    <thead>
      <tr>
        <th>lawyer_id</th>
        <th>Meeting Place</th>
        <th>Meeting Date</th>
        <th>Status</th>
      </tr>
    </thead>
    <tbody>
      