<?php
$admin_user=$_SESSION['admin_user'];
if(!$admin_user)
{
	return redirect('admin/admin_start');
}
?>
<!Doctype html>
<html>
<head>
		<meta charset='UTF-8'>
	    <title>Lawyer See Request</title>
	    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	
	

</head>
<body>

<div id="login" style>

<center><h2>Lawyer Meeting Request</h2></center>

</div>

<table class="table table-striped">
    <thead>
	<tr>
        <th>Name of user</th>
        <th>Phone Number</th>
        <th>Email Id</th>
        <th>Meeting Place</th>
        <th>Meeting Date</th>
        <th>Accept Request</th>
        <th>Denial Request</th>
      </tr>
    </thead>
    <tbody>
      
	  
      
	  

     
   
