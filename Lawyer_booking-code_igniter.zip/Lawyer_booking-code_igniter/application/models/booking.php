<?php
class Booking extends CI_Model{

public function check($name,$phone_no,$email_id,$age,$lawyer_id,$gender,$meetplace,$meetingdate){
	$user_id=$_SESSION['user_id'];
	$query="INSERT INTO `booking`(`id`,user_id, `name`, `phone_no`, `email_id`, `age`, `lawyer_id`, `gender`, `meetplace`, `meetingdate`) 
	        VALUES ('','$user_id','$name','$phone_no','$email_id','$age','$lawyer_id','$gender','$meetplace','$meetingdate')";
		
if($result=$this->db->query($query))
         return true;
else
  return 
false;	
}

}

?>