<?php
class Validlogin extends CI_Model{
	
	public function index($username,$password){
		
		$q=$this->db->where(['username'=>$username,'password'=>$password])->get('user');
		if($q->num_rows())
		{
			return $q->row()->username;
		}
		else{
			return false;
		}
	}
	public function adminlogin($username,$password){
		
		$q=$this->db->where(['username'=>$username,'password'=>$password])->get('admin');
		if($q->num_rows())
		{
			return $q->row()->username;
		}
		else{
			return false;
		}
	}
	
	
}


?>
