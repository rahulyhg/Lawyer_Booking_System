<?php
class Getuser extends CI_Model{

public function index(){
$lawyer_id=$_SESSION['admin_user'];
$approve=0;
$q=$this->db->where(['lawyer_id'=>$lawyer_id,'approve'=>$approve])->get('booking');
if($q->num_rows()){

return $q->result_array();
}
else
	return false;
}
public function getmeeting(){
$user_id=$_SESSION['user_id'];

$q=$this->db->where(['user_id'=>$user_id])->get('booking');

if($q->num_rows()){

return $q->result_array();
}

}
public function accept($id){
	$query="UPDATE `booking` SET `approve`=1,`accept`=1 WHERE id='$id'";
	$this->db->query($query);
	return true;
	
}
public function deny($id){
	$query1="UPDATE `booking` SET `approve`=1,accept=0,`deny`=1 WHERE id='$id'";
	$this->db->query($query1);
	return true;
	
}
}


?>