<?php

class Book extends CI_Controller{

public function confirm(){
            $name=$this->input->post('name');
			$phone_no=$this->input->post('phone_no');
			$email_id=$this->input->post('email_id');
			$age=$this->input->post('age');
			$lawyer_id=$this->input->post('lawyer_id');
			$gender=$this->input->post('gender');
			$meetplace=$this->input->post('meetplace');
			$meetingdate=$this->input->post('meetingdate');
		    
			$this->load->model('booking');
			$test=$this->booking->check($name,$phone_no,$email_id,$age,$lawyer_id,$gender,$meetplace,$meetingdate);
			if($test)
				return redirect('book/showmessage');
			
			

}
public function showmessage()
{
	$this->load->view('legistify/showmessage');
}
}


?>