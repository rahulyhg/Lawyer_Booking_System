<?php
class Admin extends CI_Controller
{

public function admin_start(){
	$this->load->view('legistify/admin');
	
	
}
public function confirm(){
	    $this->load->library('form_validation');
		$this->form_validation->set_rules('username','Username','required|alpha_numeric');
		$this->form_validation->set_rules('password','Password','required|alpha_numeric');
		
		if($this->form_validation->run() )
		{
			$username=$this->input->post('username');
			$password=$this->input->post('password');
			$this->load->model('validlogin');
			$test=$this->validlogin->adminlogin($username,$password);
			if($test)
			{
				$this->load->library('session');
				$this->session->set_userdata('admin_user',$test);
				return redirect("getuser1/get1");
			}
			else{
				echo "<script>alert('Incorrect Username and Password ');</script>";
			   $this->load->view('legistify/admin');
			}
		}
		else
		{
			$this->load->view('legistify/admin');
		}
	
}
public function admin_see_request(){
		
		$this->load->view('legistify/admin_see_request');
	}
public function admin_logout(){
	$this->load->library('session');
    $this->session->unset_userdata('admin_user');
	return redirect('admin/admin_start');
	
}

}
?>