<?php
class Getuser1 extends CI_Controller{
public function get1()
{
	$this->load->model('getuser');
	$this->load->view('legistify/admin_see_request');
	if($data['users']=$this->getuser->index())
	{
	$this->load->view('legistify/admin_see_request2',$data);}
	$this->load->view('legistify/admin_see_request3');
	
}
public function get2()
{
	$this->load->model('getuser');
	$this->load->view('legistify/form_requirements');
	$this->load->view('legistify/form_requirements1');
	if($data['meetings']=$this->getuser->getmeeting())
	{
		
	$this->load->view('legistify/form_requirements3',$data);
	}
	$this->load->view('legistify/form_requirements2');
	
}
public function accept(){
	$id=$this->input->post('id');
	$this->load->model('getuser');
	$accept=$this->getuser->accept($id);
	if($accept)
		return redirect('getuser1/get1');
}
public function deny(){
	$id=$this->input->post('id');
	$this->load->model('getuser');
	$deny=$this->getuser->deny($id);
	if($deny)
		return redirect('getuser1/get1');
}
}


?>