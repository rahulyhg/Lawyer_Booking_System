<?php
class Load extends CI_Controller{
	
	public function index(){
		$this->load->view('legistify/index');
		
	} 
	public function user_start(){
		$this->load->view('legistify/user_start');
		
	}
	public function formvalid(){
		
		$this->load->library('form_validation');
		$this->form_validation->set_rules('username','Username','required|alpha_numeric');
		$this->form_validation->set_rules('password','Password','required|alpha_numeric');
		
		if($this->form_validation->run() )
		{
			$username=$this->input->post('username');
			$password=$this->input->post('password');
			$this->load->model('validlogin');
			$test=$this->validlogin->index($username,$password);
			if($test)
			{
				$this->load->library('session');
				$this->session->set_userdata('user_id',$test);echo"test";
				return redirect("getuser1/get2");
			}
			else{
			echo "<script>alert('Incorrect Username and Password');</script>";
			$this->load->view('legistify/user_start');
			}
		}
		else
		{
			$this->load->view('legistify/user_start');
		}
	}
	public function user_logout(){
		
		        $this->load->library('session');
				$this->session->unset_userdata('user_id');
				return redirect('load/user_start');
	}
	
	
}


?>